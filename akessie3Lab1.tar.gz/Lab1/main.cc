/**For your final submission this main function
   must be identical to this one; however, I 
	highly encourage you to comment out many
   of the lines as you create and debug your
	program!! -- Dr. DeCode
**/

#include <cstdlib>
#include <ctime>
#include "myRoulette.h"

using namespace std;

int main()
{
			  srand(time(0));

			  RouletteTable table1;

			  //roll the ball and print number to output terminal
			  cout << table1.rollBall() << endl;

			  //make the basic grid that numbers will go into
			  table1.drawGrid();		

			  //Now put in the circles
			  table1.drawRedBlackCircles();

			  //Now put in the numbers
			  table1.drawNumbersOnBoard();

			  //Now mark the board with the winning number!
			  table1.markBoard();

			  //Now export the information to the outputfile	
			  table1.exportPGMFile("rouletteImage.pgm"); 

} 

