#include <vector>

//This is the header file for the
//class definitions that are used in Lab1
//Please note you don't have to understand this
//file because I have put in elements that we cover
//later. You can just use the objects and the
//member functions at a high level as specified
//in the lab.


//Here are some constant definitions that I use

#define w 255
#define b 155

#define NumberRow 30 
#define NumberCol 14 

#define Board_Columns 300
#define Board_Rows 900

class NumberPixels
{


	public:

	int returnPixelValue(int, int, int, int) const;
	//RETURN VALUE: This is the greyscale number for the pixel
	//FIRST VALUE: the number you want to find the pixel value for
	//SECOND VALUE: the row location in the number font image
	//THIRD VALUE: the col location in the number font image
	//FOURTH VALUE: the background color of the number font image
	
	private:

	const std::vector <int> One = 
				   {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				    0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, w, w, w, w, w, w, w, 0, 0, 0, 0, 
				    0, w, w, w, w, w, w, w, w, w, 0, 0, 0, 0, 
				    w, w, w, w, w, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				    w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				    w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				    w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				    w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


const std::vector <int> Two = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, 0, 0, 0,
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0,
				   0, w, w, w, w, w, w, w, w, w, w, w, 0, 0,
				   0, w, w, w, w, 0, 0, 0, w, w, w, w, w, 0,
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0,
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, w, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, w, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

const std::vector <int> Three = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, 0, 0, 0,
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0,
				   0, w, w, w, w, w, w, w, w, w, w, w, 0, 0,
				   0, w, w, w, w, 0, 0, 0, w, w, w, w, w, 0,
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0,
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, w, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, w, w, w, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0,
				   0, 0, 0, 0, 0, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


const std::vector <int> Four = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, w, w, w, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, w, w, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, w, w, w, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, w, w, w, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, w, w, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   w, w, w, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   w, w, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

const std::vector <int> Five = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   w, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, w, w, w, 0, 0, 0, 0, 
				   w, w, w, w, 0, w, w, w, w, w, w, 0, 0, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, w, 0, 0, 0, 0, w, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, w, w, w, w, w, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

const std::vector <int> Six = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, w, w, 0, 0, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, 0, 0, 0, w, w, w, 0, 0, 0, 0, 
				   0, w, w, w, 0, w, w, w, w, w, w, 0, 0, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, 0, 0, 0, 0, 0, w, w, w, w, w, 
				   0, w, w, w, w, 0, 0, 0, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

const std::vector <int> Seven = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   w, w, w, w, w, w, w, w, w, w, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

const std::vector <int> Eight = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   w, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, w, 
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

const std::vector <int> Nine = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, w, w, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };

const std::vector <int> Zero = 
				  {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
				   0, 0, 0, 0, w, w, w, w, w, w, 0, 0, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, 0, 0, 0, 0, 0, 0, w, w, w, 0, 
				   0, w, w, w, w, 0, 0, 0, 0, w, w, w, w, 0, 
				   0, w, w, w, w, w, w, w, w, w, w, w, w, 0, 
				   0, 0, w, w, w, w, w, w, w, w, w, w, 0, 0, 
				   0, 0, 0, w, w, w, w, w, w, w, w, 0, 0, 0, 
				   0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };


};

class _2DPixelArray
{

	//This is a wrapper about a 2D array to help simplify the 
	//Lab 0 since we have not talked about vectors yet!! 


	public: 

		//this is the default constructor that initializes the vector
		//This will create an array that is Board_Rows by Board_Columns
		_2DPixelArray();

		//this allows you to call the object using the indexing operator
		//This is way beyond our discussion..just use it for now
		std::vector <int> & operator[](int row_num);

	private:
		 int rows, columns;
		 std::vector < std::vector <int> > pixelArray;
};
