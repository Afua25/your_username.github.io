#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cmath>
#include "numbers.h"

using namespace std;

//This is a way to make constants in 
//C and C++ -- we will talk more later
//but realize you can use them anywhere
//in files that include this header file

#define Square_Dimension 65
#define Offset 50 
#define Max_Pixel_Value 255
#define White 255
#define Black 0
#define Red 155
#define Background 
#define CircleRadius 28 

class RouletteTable
{
	public:
		int rollBall();	
		//DESCRIPTION: This will roll the ball with a random number generator 
		//RETURN VALUE: THis will return the random number generated 

		void exportPGMFile(string filename);
      //DESCRIPTION: This creates output file that has the PGM file format in it
		//FIRST VALUE: This is the name of the output file  

		void drawRect(int, int, int, int, int); 
		//DESCRIPTION: Call this member function to draw a circle in rBoard
		//FIRST VALUE: This is the row of the upper right corner of the rectangle
		//SECOND VALUE: This is the column of the upper right corner of the rectangle
		//THIRD VALUE: This is the length of the rectangle
		//FOURTH VALUE: This is the width of the rectangle
		//FIFTH VALUE: This is the color of the line of the rectangle

		void drawGrid();
		//DESCRIPTION: This MF places grid portion of roulette table image into rBoard

		void drawCircle(int,int,int, int); 
		//DESCRIPTION: Call this member function to draw a circle in rBoard
		//RETURN VALUE : This member function does not return a value
		//FIRST VALUE : The row of the center of the circle 
		//SECOND VALUE : The column of the center of the circle
		//THIRD VALUE : The radius of the circle
		//FOURTH VALUE : The color of the outer perimeter of the circle 

		void drawFilledCircle(int,int,int, int); 
		//DESCRIPTION: Call this member function to draw a filled circle in rBoard
		//RETURN VALUE : This member function does not return a value
		//FIRST VALUE : The row of the center of the circle 
		//SECOND VALUE : The column of the center of the circle
		//THIRD VALUE : The radius of the circle
		//FOURTH VALUE : The color of the  circle filling

		void drawRedBlackCircles();
		//DESCRIPTION: This will draw the grid of red and black circles

		void drawSingleDigitNumber(int, int,int,int); 
		//DESCRIPTION : This member function will draw a single digital number in the field
		//FIRST VALUE : The number that want to draw on the board
		//SECOND VALUE : The row of the upper left corner of where the number will be placed
		//THIRD VALUE: The column of the upper right corner of where the number will be placed
		//FOURTH VALUE: The background color of the number

		void drawDoubleDigitNumber(int, int, int,int,int); 
		//DESCRIPTION : This member function will draw a double digital number in the field
		//FIRST VALUE : The first number to draw on the board for double digit number
		//SECOND VALUE : The second number to draw on the board for double digit number
		//THIRD VALUE : The row of the upper left corner of where the number will be placed
		//FOURTH VALUE: The column of the upper right corner of where the number will be placed
		//FIFTH VALUE: The background color of the number

		void drawTheNumber(int, int,int,int); 
		//DESCRIPTION : This member function will any number from 1 to 36 
		//FIRST VALUE : The first number that want to draw on the board
		//SECOND VALUE : The row of the upper left corner of where the number will be placed
		//THIRD VALUE: The column of the upper right corner of where the number will be placed
		//FOURTH VALUE: The background color of the number

		void drawNumbersOnBoard();
		//DESCRIPTION: This will position the numbers and draw 1 - 36 on the board

		void markBoard();
		//DESCRIPTION: This MF will draw a circle around the number that is rolled

		
	private:

		int number; //this holds the random number generated

		_2DPixelArray rBoard; //this is the internal data structure that holds 2D pixel array

};

