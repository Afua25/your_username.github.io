#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <cmath>
#include <cstdlib>
#include "myRoulette.h"
#include <iomanip>

/*
Author: Afua Kessie
Class: ECE2036
Last Date Modified: 9/18/2022

Description: Creating a roulette table that successfully circles the random number that has been rolled

 */

using namespace std;


const NumberPixels numPixelObject; //would be more efficient in global variable

//--------------------------------------------------------------------------------
int RouletteTable::rollBall()
//DESCRIPTION: This will roll the ball with a random number generator 
//RETURN VALUE: THis will return the random number generated 
{
	number = rand()%35+1;	

	//QUESTION 1. Please return the number as an output of this member function
        return number;        


	//---- END QUESTION  1.

}//end rollBall

//--------------------------------------------------------------------------------
void RouletteTable::exportPGMFile(string filename)
//DESCRIPTION: This creates output file that has the PGM file format in it
//FIRST VALUE: This is the name of the output file  
{
			  ofstream outfile(filename, ios::out);

			  outfile << "P2" << endl; //magic number
			  outfile <<"#This is the image of a roulette table" << endl; //comment
			  outfile << Board_Columns << " " << Board_Rows << endl; //col row specification
			  outfile << Max_Pixel_Value << endl; //maximum pixel value


			  for (int i = 0; i < Board_Rows; i++) // start with the ith row 
			  {
				  for (int j = 0; j < Board_Columns; j++) // now print out the row
					{

					 //QUESTION 2. Please send the pixel value rBoard[i][j] to the output file!
                //   Output each pixel value in a field with a width of 4 using io manipulator.
                                         outfile << setw(4) << rBoard[i][j]; 


					//----- END QUESTION 2.
					}
			  
					outfile << endl;

			  } //outer for loop  

			  outfile.close();	
					
}


//--------------------------------------------------------------------------------
void RouletteTable::drawRect(int row, int column, int len, int width, int pixValue)
//DESCRIPTION: Call this member function to draw a circle in rBoard
//FIRST VALUE: This is the row of the upper right corner of the rectangle
//SECOND VALUE: This is the column of the upper right corner of the rectangle
//THIRD VALUE: This is the length of the rectangle
//FOURTH VALUE: This is the width of the rectangle
//FIFTH VALUE: This is the color of the line of the rectangle
{

//Now let's do some error checking remember zero indexing
if ((row+width < Board_Rows)&& (row >= 0) &&(column+len < Board_Columns) && (column >= 0))
//then you will not go out of bounds of the 2D array
{

	//draw top line
	for (int i = column; i < column+len; i++) 	
		rBoard[row][i] = pixValue; 

	//QUESTION 3. insert code to draw the bottom line of the rectangle
        for (int i = column; i < column+len; i++)
                rBoard[row + width][i] = pixValue;



	//---- END QUESTION 3.
	
	//QUESTION 4. insert code to draw the left side of the rectangle
        for (int i = row; i < row + width; i++)
                rBoard[i][column] = pixValue;



	// ---- END QUESTION 4. 

	//QUESTION 5. insert code to draw the right side of the rectangle
        for (int i = row; i < row + len; i++)
                rBoard[i][column + len] = pixValue;


	// ---- END QUESTION 5. 

} //end error checking if
else
{
	cout << "DrawRect out of bounds ERROR" << endl;
}


}//end drawRect

//--------------------------------------------------------------------------------
void RouletteTable::drawGrid()
//DESCRIPTION: This MF places grid portion of roulette table image into rBoard
{

	//QUESTION 6. Please use two nested for loops to draw the square grid
	//	  			  as indicated in the figure 9(b) in the lab specifications. You 
	//	  			  will need to call your drawRect function! 

          int rows = 12;
          int columns = 3;

          for (int i = 0; i < rows; i++) //go through the rows 
          {                             
                for(int j = 0; j < columns; j++) //go through the columns 
                {
                 drawRect(Offset+i*Square_Dimension,Offset+j*Square_Dimension,65,65,255);//repeats the squares/columns to create square grid 
                } 
                
          }






	//---- END QUESTION 6.

}//end drawGrid

//--------------------------------------------------------------------------------

void RouletteTable::drawCircle(int row, int col, int radius, int pixValue)
//DESCRIPTION: Call this member function to draw a circle in rBoard
//RETURN VALUE : This member function does not return a value
//FIRST VALUE : The row of the center of the circle 
//SECOND VALUE : The column of the center of the circle
//THIRD VALUE : The radius of the circle
//FOURTH VALUE : The color of the outer perimeter of the circle 
{

//SPECIAL NOTES:
//note you will need to include the cmath library to get the sqrt to work!! 
//We have to use some symmetry to get a solid perimeter of the circle;
//otherwise the mapping of the continuous to discrete world will give you a faint 
//circle.  I will try to use the 8-way symmetry of the circle here

	int y_value;
	int counter = 0;

//lets put a pixel at each of  the 4 extremes on circle

	rBoard[row][col+radius] = pixValue;
        rBoard[row][col-radius] = pixValue;
	rBoard[row+radius][col] = pixValue;
	rBoard[row-radius][col] = pixValue;

	counter = col;	

	for (int x = 1; x < radius ; x++) 	
	{
		y_value = sqrt( radius*radius - x*x);

		//just for comparison here is the 4-way symmetry
			  
		//lower right quadrant
		rBoard[row + y_value][col+x] = pixValue; 
		//lower left quadrant
		rBoard[row + y_value][col-x] = pixValue;
		//upper right quadrant
		rBoard[row-y_value][col+x] = pixValue;
		//upper left quadrant
		rBoard[row-y_value][col-x] = pixValue;

		//let's utilize the fact that a circle also
		//has 8 way symmetry!!

		rBoard[row + x][col + y_value] = pixValue;
		rBoard[row + x][col - y_value] = pixValue;
		rBoard[row - x][col + y_value] = pixValue;
		rBoard[row - x][col - y_value] = pixValue;

		}

} 

//--------------------------------------------------------------------------------
void RouletteTable::drawFilledCircle(int row, int col, int radius, int pixValue)
//DESCRIPTION: Call this member function to draw a filled circle in rBoard
//RETURN VALUE : This member function does not return a value
//FIRST VALUE : The row of the center of the circle 
//SECOND VALUE : The column of the center of the circle
//THIRD VALUE : The radius of the circle
//FOURTH VALUE : The color of the  circle filling
{

		//QUESTION 7.  You will  need to figure out how to do this entire member function.
      //	   			Think about how you would use elements of the drawCircle() member
		//					function. Study the other functions to figure this out!!          

// 4 extremes of the circle 
      rBoard[row][col + radius] = pixValue; 
      rBoard[row][col - radius] = pixValue;
      rBoard[row+radius][col] = pixValue;
      rBoard[row-radius][col] = pixValue;      

      int y_value; //initialize y value 

      for (int x = 1;  x < radius; x++)
      { 
        y_value = sqrt( radius*radius - x*x);
        rBoard[row + x][col + y_value] = pixValue;
        rBoard[row + x][col - y_value] = pixValue;
        rBoard[row - x][col + y_value] = pixValue;
        rBoard[row - x][col - y_value] = pixValue;
        rBoard[row][col + x] = pixValue;
        rBoard[row][col - x] = pixValue;
        rBoard[row - x][col] = pixValue;
        rBoard[row + x][col] = pixValue;
        rBoard[row][col] = pixValue;

        for (int i = col - x; i < col + x; i++) //for loops runs through the rows and columns to fill in the circle with desired color
         {
            rBoard[row - y_value][i] = pixValue;
            rBoard[row + y_value][i] = pixValue;
         }
        for (int i = row - y_value; i < row + y_value; i++)
        {
            rBoard[i][col - x] = pixValue;
            rBoard[i][col + x] = pixValue;
        }

      }

     




		//--- END QUESTION 7.
 
} 

//--------------------------------------------------------------------------------
void RouletteTable::drawRedBlackCircles()
//DESCRIPTION: This will draw the grid of red and black circles
{


	//SPECIAL NOTE: I will give this member function to you! However
	// 				 you can change this if you want

	bool black = true;
	for (int i = 0; i < 12; i++)
		for (int j = 0; j < 3; j++)
		{
			drawFilledCircle(Offset+Square_Dimension/2 +i*Square_Dimension,
								  Offset+Square_Dimension/2 + j*Square_Dimension,
								  CircleRadius, (black)? Black:Red);

			//Notice I used a conditional operator!! Ask me about it in class! 
	
			black = !black; //notice I use this to toggle back and forth
		}
	
}//end drawRedBlackCircles

//--------------------------------------------------------------------------------
void RouletteTable::drawSingleDigitNumber(int number, int row, int col, int bg)
//DESCRIPTION : This member function will draw a single digital number in the field
//FIRST VALUE : The number that want to draw on the board
//SECOND VALUE : The row of the upper left corner of where the number will be placed
//THIRD VALUE: The column of the upper left corner of where the number will be placed
//FOURTH VALUE: The background color of the number

{

            //SPECIAL NOTES: I will give you this function so that you can use it in a  
            //                                         higher level function 

            int counter = 0;
            for (int i = 0; i < NumberRow ; i++) //include numPixelObject.numRow()
                    for (int j = 0; j < NumberCol ; j++) //include numPixelObject.numCol()
                {
                      rBoard[row+i][col+j] = numPixelObject.returnPixelValue(number,i,j,bg);
                }
            
}//END SingleDigitNumber

//--------------------------------------------------------------------------------
void RouletteTable::drawDoubleDigitNumber(int num1, int num2, int row, int col, int bg)
//DESCRIPTION : This member function will draw a double digital number in the field
//FIRST VALUE : The first number to draw on the board for double digit number
//SECOND VALUE : The second number to draw on the board for double digit number
//THIRD VALUE : The row of the upper left corner of where the number will be placed
//FOURTH VALUE: The column of the upper right corner of where the number will be placed
//FIFTH VALUE: The background color of the number

{

		//QUESTION 8.  You will need to make this function.  Remember to reuse
		//					the member functions that you have previously created.
               drawSingleDigitNumber(num1, row, col, bg);//draws the left number 
               drawSingleDigitNumber(num2, row, col + 15, bg); //draws the right number to take into account the double digit


		//-- QUESTION 8. END
}

//--------------------------------------------------------------------------------
void RouletteTable::drawTheNumber(int num, int row,int col,int bg)
//DESCRIPTION : This member function will any number from 1 to 36 
//FIRST VALUE : The first number that want to draw on the board
//SECOND VALUE : The row of the upper left corner of where the number will be placed
//THIRD VALUE: The column of the upper right corner of where the number will be placed
//FOURTH VALUE: The background color of the number
{
	
// SPECIAL NOTE:  I will also give this member function to you as well.  We will talk about 
// 					switch/case statments next week but this is a nice example
// 					here.

			  switch (num)
			  {
				  case 1: drawSingleDigitNumber(1,row,col ,bg);	break;
				  case 2: drawSingleDigitNumber(2,row,col,bg); break;	
				  case 3: drawSingleDigitNumber(3,row,col ,bg); break;	
				  case 4: drawSingleDigitNumber(4,row,col ,bg); break;	
				  case 5: drawSingleDigitNumber(5,row,col ,bg); break;	
				  case 6: drawSingleDigitNumber(6,row,col ,bg); break;	
				  case 7: drawSingleDigitNumber(7,row,col ,bg); break;	
				  case 8: drawSingleDigitNumber(8,row,col ,bg); break;	
				  case 9: drawSingleDigitNumber(9,row,col ,bg); break;	
				  case 10: drawDoubleDigitNumber(1,0,row,col ,bg); break;	
				  case 11: drawDoubleDigitNumber(1,1,row,col ,bg); break;	
				  case 12: drawDoubleDigitNumber(1,2,row,col ,bg); break;	
				  case 13: drawDoubleDigitNumber(1,3,row,col ,bg); break;	
				  case 14: drawDoubleDigitNumber(1,4,row,col ,bg); break;	
				  case 15: drawDoubleDigitNumber(1,5,row,col ,bg); break;	
				  case 16: drawDoubleDigitNumber(1,6,row,col ,bg); break;	
				  case 17: drawDoubleDigitNumber(1,7,row,col ,bg); break;	
				  case 18: drawDoubleDigitNumber(1,8,row,col ,bg); break;	
				  case 19: drawDoubleDigitNumber(1,9,row,col ,bg); break;	
				  case 20: drawDoubleDigitNumber(2,0,row,col ,bg); break;	
				  case 21: drawDoubleDigitNumber(2,1,row,col ,bg); break;	
				  case 22: drawDoubleDigitNumber(2,2,row,col ,bg); break;	
				  case 23: drawDoubleDigitNumber(2,3,row,col ,bg); break;	
				  case 24: drawDoubleDigitNumber(2,4,row,col ,bg); break;	
				  case 25: drawDoubleDigitNumber(2,5,row,col ,bg); break;	
				  case 26: drawDoubleDigitNumber(2,6,row,col ,bg); break;	
				  case 27: drawDoubleDigitNumber(2,7,row,col ,bg); break;	
				  case 28: drawDoubleDigitNumber(2,8,row,col ,bg ); break;	
				  case 29: drawDoubleDigitNumber(2,9,row,col ,bg ); break;	
				  case 30: drawDoubleDigitNumber(3,0,row,col ,bg ); break;	
				  case 31: drawDoubleDigitNumber(3,1,row,col ,bg ); break;	
				  case 32: drawDoubleDigitNumber(3,2,row,col ,bg ); break;	
				  case 33: drawDoubleDigitNumber(3,3,row,col ,bg ); break;	
				  case 34: drawDoubleDigitNumber(3,4,row,col ,bg ); break;	
				  case 35: drawDoubleDigitNumber(3,5,row,col ,bg ); break;	
				  case 36: drawDoubleDigitNumber(3,6,row,col ,bg ); break;	
			};

//Need to drawTwoNumber function

}//end DrawTheNumber

//--------------------------------------------------------------------------------

void RouletteTable::drawNumbersOnBoard()
//DESCRIPTION: This will position the numbers and draw 1 - 36 on the board
{
				bool black = true;
				int counter = 1;
		      for (int i = 0; i < 12; i++)
					for (int j = 0; j < 3; j++)
					{

					//QUESTION 9: Here you will need to draw the correct number
					//				  make sure you use previous member function(s) 
					//				  to help you.  If you want to recreate this 
					//				  entire function you may do so!

                                        drawTheNumber(counter, Offset+Square_Dimension/4 + i*Square_Dimension, Offset+Square_Dimension/4 + j*Square_Dimension, (black)?  Black:Red);
                                      
                                        counter++;//helps to not repeat same numbers but go through 1-36

                                        
					//---- END QUESTION 9.
					black = !black;
					}

}//end drawNumbersOnBoard
			
//--------------------------------------------------------------------------------
void RouletteTable::markBoard()
//DESCRIPTION: This MF will draw a circle around the number that is rolled!
{

	//QUESTION 10. You will need to find the correct position on the board
	//					based on the random number that is choosen and circle the
	//					the number on the board.

        //Through these functions help to determine which white circle to draw with the random number that is rolled.
        int i = (number - 1) / 3;
        if (number % 3 != 0)
        {
             int k = (number - 1) % 3;
             drawCircle(Offset + i*Square_Dimension + Square_Dimension/2, Offset + k*Square_Dimension + Square_Dimension/2, CircleRadius + 9, White);
        }     
        else
        {
             int k = 2;
             drawCircle(Offset + i*Square_Dimension + Square_Dimension/2, Offset + k*Square_Dimension + Square_Dimension/2, CircleRadius + 9, White);
        } 







	//---- END QUESTION 10.
}//end markBoard



